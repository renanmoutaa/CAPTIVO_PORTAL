-- =================================================================
-- HOTSPOT PRO - TENANT DATABASE SCHEMA
-- Criado dinamicamente para cada novo usuário SaaS
-- =================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- -----------------------------------------------------------------
-- Tabela: connected_clients (Leads capturados no portal)
-- -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS connected_clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL DEFAULT 'Visitante',
    email TEXT NOT NULL DEFAULT 'n/a',
    phone TEXT,
    cpf TEXT,
    device TEXT,
    ip TEXT,
    mac TEXT UNIQUE NOT NULL,
    status TEXT DEFAULT 'online',
    location TEXT DEFAULT 'default',
    bandwidth_used BIGINT DEFAULT 0,
    connected_at TIMESTAMPTZ DEFAULT NOW(),
    last_seen TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------------------
-- Tabela: controllers (Controladores UniFi do tenant)
-- -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS controllers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    location TEXT,
    ip TEXT,
    model TEXT,
    clients_count INTEGER DEFAULT 0,
    max_clients INTEGER DEFAULT 500,
    status TEXT DEFAULT 'online',
    uptime TEXT,
    load INTEGER DEFAULT 0,
    bandwidth TEXT,
    version TEXT,
    site TEXT DEFAULT 'default',
    ssid TEXT,
    access_points INTEGER DEFAULT 0,
    networks INTEGER DEFAULT 0,
    port TEXT DEFAULT '8443',
    unifi_username TEXT,
    unifi_password TEXT,
    unifi_api_key TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- -----------------------------------------------------------------
-- Tabela: portal_settings (Configurações visuais do portal)
-- -----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS portal_settings (
    id TEXT PRIMARY KEY DEFAULT 'default',
    background_type TEXT DEFAULT 'gradient',
    background_color TEXT DEFAULT '#1e293b',
    gradient_start TEXT DEFAULT '#667eea',
    gradient_end TEXT DEFAULT '#764ba2',
    background_image TEXT DEFAULT '',
    primary_color TEXT DEFAULT '#667eea',
    font_family TEXT DEFAULT 'inter',
    border_radius INTEGER DEFAULT 16,
    opacity INTEGER DEFAULT 95,
    blur_effect BOOLEAN DEFAULT false,
    card_shadow BOOLEAN DEFAULT true,
    card_background_color TEXT DEFAULT '#ffffff',
    card_background_image TEXT DEFAULT '',
    card_width INTEGER DEFAULT 448,
    card_min_height INTEGER DEFAULT 0,
    card_image_size INTEGER DEFAULT 100,
    card_image_position_x INTEGER DEFAULT 50,
    card_image_position_y INTEGER DEFAULT 50,
    form_margin_top INTEGER DEFAULT 0,
    show_logo BOOLEAN DEFAULT true,
    logo_url TEXT DEFAULT '',
    logo_size INTEGER DEFAULT 80,
    show_title BOOLEAN DEFAULT true,
    title_text TEXT DEFAULT 'Conecte-se ao WiFi Grátis',
    show_subtitle BOOLEAN DEFAULT true,
    subtitle_text TEXT DEFAULT 'Faça login para continuar navegando',
    input_bg_color TEXT DEFAULT 'transparent',
    input_text_color TEXT DEFAULT '#333333',
    input_border_color TEXT DEFAULT '#cbd5e1',
    button_text_color TEXT DEFAULT '#ffffff',
    login_email BOOLEAN DEFAULT true,
    field_name_required BOOLEAN DEFAULT true,
    field_email_required BOOLEAN DEFAULT true,
    field_phone_required BOOLEAN DEFAULT true,
    field_birthdate_required BOOLEAN DEFAULT false,
    field_cpf_required BOOLEAN DEFAULT false,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO portal_settings (id) VALUES ('default') ON CONFLICT DO NOTHING;
