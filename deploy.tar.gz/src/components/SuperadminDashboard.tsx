import { useState, useEffect } from 'react';
import { useSaasAuth } from '../contexts/SaasAuthContext';
import {
    Users, Wifi, Shield, TrendingUp, Plus, Search, Edit, Trash2,
    CheckCircle, XCircle, AlertCircle, ChevronDown
} from 'lucide-react';

interface Tenant {
    id: string;
    name: string;
    email: string;
    company_name: string;
    status: string;
    controllers_count: number;
    clients_count: number;
    created_at: string;
    last_login: string | null;
    plan_name: string;
}

interface Stats {
    total_tenants: number;
    total_controllers: number;
    by_status: { status: string; count: string }[];
    by_plan: { name: string; users: string }[];
}

interface Plan {
    id: string;
    name: string;
}

export function SuperadminDashboard() {
    const { user, logout } = useSaasAuth();
    const [tenants, setTenants] = useState<Tenant[]>([]);
    const [stats, setStats] = useState<Stats | null>(null);
    const [plans, setPlans] = useState<Plan[]>([]);
    const [search, setSearch] = useState('');
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState<'dashboard' | 'tenants' | 'create'>('dashboard');
    const [form, setForm] = useState({ name: '', email: '', password: '', company_name: '', plan_id: '' });
    const [formError, setFormError] = useState('');
    const [formSuccess, setFormSuccess] = useState('');
    const [creating, setCreating] = useState(false);

    const headers = { 'Authorization': `Bearer ${user?.token}`, 'Content-Type': 'application/json' };

    const fetchData = async () => {
        setLoading(true);
        try {
            const [tenantsRes, statsRes] = await Promise.all([
                fetch('/api/superadmin/tenants', { headers }),
                fetch('/api/superadmin/stats', { headers }),
            ]);
            setTenants(await tenantsRes.json());
            setStats(await statsRes.json());
        } catch (e) { console.error(e); }
        setLoading(false);
    };

    useEffect(() => { fetchData(); }, []);

    const handleCreate = async (e: React.FormEvent) => {
        e.preventDefault();
        setCreating(true);
        setFormError('');
        setFormSuccess('');
        try {
            const res = await fetch('/api/superadmin/tenants', {
                method: 'POST',
                headers,
                body: JSON.stringify(form)
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error);
            setFormSuccess(`Usuário "${form.name}" criado com sucesso! Banco de dados isolado gerado.`);
            setForm({ name: '', email: '', password: '', company_name: '', plan_id: '' });
            fetchData();
            setActiveTab('tenants');
        } catch (err: any) {
            setFormError(err.message);
        }
        setCreating(false);
    };

    const handleToggleStatus = async (tenant: Tenant) => {
        const newStatus = tenant.status === 'active' ? 'suspended' : 'active';
        await fetch(`/api/superadmin/tenants/${tenant.id}`, {
            method: 'PATCH',
            headers,
            body: JSON.stringify({ ...tenant, status: newStatus })
        });
        fetchData();
    };

    const filteredTenants = tenants.filter(t =>
        t.name.toLowerCase().includes(search.toLowerCase()) ||
        t.email.toLowerCase().includes(search.toLowerCase()) ||
        (t.company_name || '').toLowerCase().includes(search.toLowerCase())
    );

    const StatCard = ({ icon: Icon, label, value, color }: any) => (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-center gap-4">
            <div className={`p-3 rounded-xl ${color}`}>
                <Icon className="w-6 h-6 text-white" />
            </div>
            <div>
                <p className="text-slate-500 text-sm">{label}</p>
                <p className="text-slate-900 text-2xl font-bold">{value}</p>
            </div>
        </div>
    );

    return (
        <div className="min-h-screen bg-slate-50">
            {/* Header */}
            <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-gradient-to-br from-violet-600 to-indigo-700 rounded-xl flex items-center justify-center">
                        <Shield className="w-5 h-5 text-white" />
                    </div>
                    <div>
                        <h1 className="font-bold text-slate-900 text-lg leading-tight">Hotspot Pro</h1>
                        <p className="text-xs text-violet-600 font-medium">Superadmin Master</p>
                    </div>
                </div>
                <div className="flex items-center gap-4">
                    <nav className="flex gap-1">
                        {(['dashboard', 'tenants', 'create'] as const).map(tab => (
                            <button
                                key={tab}
                                onClick={() => setActiveTab(tab)}
                                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                                    activeTab === tab
                                        ? 'bg-violet-100 text-violet-700'
                                        : 'text-slate-600 hover:bg-slate-100'
                                }`}
                            >
                                {tab === 'dashboard' ? 'Dashboard' : tab === 'tenants' ? 'Usuários' : '+ Novo Usuário'}
                            </button>
                        ))}
                    </nav>
                    <div className="flex items-center gap-2 pl-4 border-l border-slate-200">
                        <div className="w-8 h-8 bg-violet-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
                            {user?.name?.[0]?.toUpperCase()}
                        </div>
                        <button onClick={logout} className="text-sm text-slate-500 hover:text-slate-700">Sair</button>
                    </div>
                </div>
            </header>

            <main className="p-6 max-w-7xl mx-auto">

                {/* Dashboard Tab */}
                {activeTab === 'dashboard' && (
                    <div className="space-y-6">
                        <div>
                            <h2 className="text-2xl font-bold text-slate-900">Visão Geral do SaaS</h2>
                            <p className="text-slate-500">Monitore todos os clientes e recursos do sistema.</p>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <StatCard icon={Users} label="Total de Clientes" value={stats?.total_tenants ?? '—'} color="bg-violet-500" />
                            <StatCard icon={Wifi} label="Controladoras Ativas" value={stats?.total_controllers ?? '—'} color="bg-blue-500" />
                            <StatCard icon={CheckCircle} label="Clientes Ativos" value={stats?.by_status?.find(s => s.status === 'active')?.count ?? '0'} color="bg-emerald-500" />
                            <StatCard icon={TrendingUp} label="Plano Enterprise" value={stats?.by_plan?.find(p => p.name === 'Enterprise')?.users ?? '0'} color="bg-orange-500" />
                        </div>

                        {/* Recent Tenants */}
                        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                                <h3 className="font-semibold text-slate-900">Clientes Recentes</h3>
                                <button onClick={() => setActiveTab('tenants')} className="text-sm text-violet-600 hover:underline">Ver todos</button>
                            </div>
                            <table className="w-full">
                                <thead className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                                    <tr>
                                        <th className="px-6 py-3 text-left">Empresa</th>
                                        <th className="px-6 py-3 text-left">Email</th>
                                        <th className="px-6 py-3 text-left">Plano</th>
                                        <th className="px-6 py-3 text-left">Controladoras</th>
                                        <th className="px-6 py-3 text-left">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {tenants.slice(0, 5).map(t => (
                                        <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                                            <td className="px-6 py-4 font-medium text-slate-900">{t.company_name || t.name}</td>
                                            <td className="px-6 py-4 text-slate-600 text-sm">{t.email}</td>
                                            <td className="px-6 py-4">
                                                <span className="px-2 py-1 bg-violet-100 text-violet-700 rounded-full text-xs font-medium">
                                                    {t.plan_name || 'Starter'}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4 text-slate-700">{t.controllers_count}</td>
                                            <td className="px-6 py-4">
                                                <span className={`flex items-center gap-1 text-xs font-medium ${t.status === 'active' ? 'text-emerald-600' : 'text-red-500'}`}>
                                                    <span className={`w-2 h-2 rounded-full ${t.status === 'active' ? 'bg-emerald-500' : 'bg-red-500'}`} />
                                                    {t.status === 'active' ? 'Ativo' : 'Suspenso'}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {/* Tenants Tab */}
                {activeTab === 'tenants' && (
                    <div className="space-y-6">
                        <div className="flex items-center justify-between">
                            <div>
                                <h2 className="text-2xl font-bold text-slate-900">Usuários do Sistema</h2>
                                <p className="text-slate-500">{tenants.length} clientes cadastrados</p>
                            </div>
                            <button
                                onClick={() => setActiveTab('create')}
                                className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-xl font-medium transition-colors"
                            >
                                <Plus className="w-4 h-4" /> Novo Usuário
                            </button>
                        </div>

                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <input
                                type="text"
                                placeholder="Buscar por nome, email ou empresa..."
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-violet-400 bg-white"
                            />
                        </div>

                        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                            <table className="w-full">
                                <thead className="bg-slate-50 text-xs text-slate-500 uppercase tracking-wider">
                                    <tr>
                                        <th className="px-6 py-3 text-left">Empresa / Usuário</th>
                                        <th className="px-6 py-3 text-left">Email</th>
                                        <th className="px-6 py-3 text-left">Plano</th>
                                        <th className="px-6 py-3 text-left">Controladoras</th>
                                        <th className="px-6 py-3 text-left">Clientes</th>
                                        <th className="px-6 py-3 text-left">Cadastro</th>
                                        <th className="px-6 py-3 text-left">Status</th>
                                        <th className="px-6 py-3 text-left">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-100">
                                    {filteredTenants.map(t => (
                                        <tr key={t.id} className="hover:bg-slate-50 transition-colors">
                                            <td className="px-6 py-4">
                                                <div className="font-medium text-slate-900">{t.company_name || t.name}</div>
                                                <div className="text-xs text-slate-400">{t.name}</div>
                                            </td>
                                            <td className="px-6 py-4 text-slate-600 text-sm">{t.email}</td>
                                            <td className="px-6 py-4">
                                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                                    t.plan_name === 'Enterprise' ? 'bg-orange-100 text-orange-700' :
                                                    t.plan_name === 'Pro' ? 'bg-blue-100 text-blue-700' :
                                                    'bg-slate-100 text-slate-600'
                                                }`}>{t.plan_name || 'Starter'}</span>
                                            </td>
                                            <td className="px-6 py-4 text-center font-semibold text-slate-700">{t.controllers_count}</td>
                                            <td className="px-6 py-4 text-center font-semibold text-slate-700">{t.clients_count}</td>
                                            <td className="px-6 py-4 text-slate-500 text-sm">
                                                {new Date(t.created_at).toLocaleDateString('pt-BR')}
                                            </td>
                                            <td className="px-6 py-4">
                                                <span className={`flex items-center gap-1 text-xs font-medium ${t.status === 'active' ? 'text-emerald-600' : 'text-red-500'}`}>
                                                    <span className={`w-2 h-2 rounded-full ${t.status === 'active' ? 'bg-emerald-500' : 'bg-red-500'}`} />
                                                    {t.status === 'active' ? 'Ativo' : 'Suspenso'}
                                                </span>
                                            </td>
                                            <td className="px-6 py-4">
                                                <button
                                                    onClick={() => handleToggleStatus(t)}
                                                    title={t.status === 'active' ? 'Suspender' : 'Reativar'}
                                                    className={`p-1.5 rounded-lg transition-colors ${t.status === 'active' ? 'text-red-500 hover:bg-red-50' : 'text-emerald-600 hover:bg-emerald-50'}`}
                                                >
                                                    {t.status === 'active' ? <XCircle className="w-4 h-4" /> : <CheckCircle className="w-4 h-4" />}
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                    {filteredTenants.length === 0 && (
                                        <tr><td colSpan={8} className="px-6 py-12 text-center text-slate-400">Nenhum usuário encontrado.</td></tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {/* Create Tenant Tab */}
                {activeTab === 'create' && (
                    <div className="max-w-lg mx-auto">
                        <div className="mb-6">
                            <h2 className="text-2xl font-bold text-slate-900">Criar Novo Usuário</h2>
                            <p className="text-slate-500">Um banco de dados isolado será criado automaticamente.</p>
                        </div>

                        <form onSubmit={handleCreate} className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
                            {formError && (
                                <div className="flex items-center gap-2 text-red-600 bg-red-50 px-4 py-3 rounded-xl text-sm">
                                    <AlertCircle className="w-4 h-4 flex-shrink-0" /> {formError}
                                </div>
                            )}
                            {formSuccess && (
                                <div className="flex items-center gap-2 text-emerald-700 bg-emerald-50 px-4 py-3 rounded-xl text-sm">
                                    <CheckCircle className="w-4 h-4 flex-shrink-0" /> {formSuccess}
                                </div>
                            )}

                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Nome Completo *</label>
                                <input required type="text" value={form.name} onChange={e => setForm({...form, name: e.target.value})}
                                    className="w-full border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-violet-400"
                                    placeholder="João Silva" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Nome da Empresa</label>
                                <input type="text" value={form.company_name} onChange={e => setForm({...form, company_name: e.target.value})}
                                    className="w-full border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-violet-400"
                                    placeholder="Restaurante do João" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Email *</label>
                                <input required type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})}
                                    className="w-full border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-violet-400"
                                    placeholder="joao@empresa.com" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-slate-700 mb-1">Senha de Acesso *</label>
                                <input required type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})}
                                    className="w-full border border-slate-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-violet-400"
                                    placeholder="Mínimo 8 caracteres" />
                            </div>

                            <button
                                type="submit"
                                disabled={creating}
                                className="w-full bg-violet-600 hover:bg-violet-700 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
                            >
                                {creating ? <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Criando...</> : <>Criar Usuário e Banco de Dados</>}
                            </button>
                        </form>
                    </div>
                )}
            </main>
        </div>
    );
}
