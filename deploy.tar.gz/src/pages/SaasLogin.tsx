import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSaasAuth } from '../contexts/SaasAuthContext';
import { Wifi, Shield, User, Eye, EyeOff, AlertCircle } from 'lucide-react';

type LoginMode = 'tenant' | 'superadmin';

export function SaasLogin() {
    const navigate = useNavigate();
    const { login } = useSaasAuth();
    const [mode, setMode] = useState<LoginMode>('tenant');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        try {
            await login(email, password, mode);
            navigate(mode === 'superadmin' ? '/superadmin' : '/admin');
        } catch (err: any) {
            setError(err.message || 'Falha no login');
        }
        setLoading(false);
    };

    return (
        <div style={{
            minHeight: '100vh',
            background: 'linear-gradient(135deg, #0f0c29 0%, #302b63 50%, #24243e 100%)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '24px',
            fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
        }}>
            <div style={{ width: '100%', maxWidth: '420px' }}>
                {/* Logo */}
                <div style={{ textAlign: 'center', marginBottom: '32px' }}>
                    <div style={{
                        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                        width: '64px', height: '64px',
                        background: 'linear-gradient(135deg, #7c3aed, #4f46e5)',
                        borderRadius: '20px',
                        boxShadow: '0 20px 40px rgba(124, 58, 237, 0.4)',
                        marginBottom: '16px'
                    }}>
                        <Wifi size={32} color="white" />
                    </div>
                    <h1 style={{ color: 'white', fontSize: '28px', fontWeight: '700', margin: '0 0 6px 0' }}>
                        Hotspot Pro
                    </h1>
                    <p style={{ color: 'rgba(167, 139, 250, 0.8)', fontSize: '14px', margin: 0 }}>
                        Plataforma de Gestão de Captive Portal
                    </p>
                </div>

                {/* Role Toggle */}
                <div style={{
                    display: 'flex', gap: '6px', padding: '6px',
                    background: 'rgba(255,255,255,0.08)',
                    borderRadius: '16px', marginBottom: '24px',
                    backdropFilter: 'blur(10px)'
                }}>
                    {([
                        { key: 'tenant', label: 'Minha Conta', Icon: User },
                        { key: 'superadmin', label: 'Superadmin', Icon: Shield }
                    ] as { key: LoginMode; label: string; Icon: typeof User }[]).map(({ key, label, Icon }) => (
                        <button
                            key={key}
                            onClick={() => { setMode(key); setError(''); }}
                            style={{
                                flex: 1,
                                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
                                padding: '10px 16px',
                                borderRadius: '12px',
                                border: 'none',
                                cursor: 'pointer',
                                fontSize: '13px',
                                fontWeight: '600',
                                transition: 'all 0.2s ease',
                                background: mode === key ? 'white' : 'transparent',
                                color: mode === key ? '#1e1b4b' : 'rgba(255,255,255,0.6)',
                                boxShadow: mode === key ? '0 4px 12px rgba(0,0,0,0.2)' : 'none',
                            }}
                        >
                            <Icon size={14} /> {label}
                        </button>
                    ))}
                </div>

                {/* Form Card */}
                <div style={{
                    background: 'rgba(255,255,255,0.06)',
                    backdropFilter: 'blur(20px)',
                    borderRadius: '24px',
                    padding: '32px',
                    border: '1px solid rgba(255,255,255,0.12)',
                    boxShadow: '0 25px 50px rgba(0,0,0,0.3)'
                }}>
                    <h2 style={{ color: 'white', fontSize: '18px', fontWeight: '600', margin: '0 0 4px 0' }}>
                        {mode === 'superadmin' ? 'Acesso Master' : 'Entrar na sua conta'}
                    </h2>
                    <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', margin: '0 0 24px 0' }}>
                        {mode === 'superadmin' ? 'Gerenciamento global do sistema' : 'Acesse seu painel de hotspot'}
                    </p>

                    <form onSubmit={handleSubmit}>
                        {error && (
                            <div style={{
                                display: 'flex', alignItems: 'center', gap: '10px',
                                background: 'rgba(239, 68, 68, 0.15)',
                                border: '1px solid rgba(239, 68, 68, 0.3)',
                                borderRadius: '12px', padding: '12px 16px',
                                color: '#fca5a5', fontSize: '13px', marginBottom: '16px'
                            }}>
                                <AlertCircle size={15} style={{ flexShrink: 0 }} />
                                {error}
                            </div>
                        )}

                        <div style={{ marginBottom: '16px' }}>
                            <label style={{ display: 'block', color: 'rgba(255,255,255,0.6)', fontSize: '13px', marginBottom: '8px', fontWeight: '500' }}>
                                Email
                            </label>
                            <input
                                type="email"
                                required
                                value={email}
                                onChange={e => setEmail(e.target.value)}
                                placeholder="seu@email.com"
                                style={{
                                    width: '100%', boxSizing: 'border-box',
                                    background: 'rgba(255,255,255,0.08)',
                                    border: '1px solid rgba(255,255,255,0.15)',
                                    borderRadius: '12px', padding: '12px 16px',
                                    color: 'white', fontSize: '14px',
                                    outline: 'none', transition: 'border-color 0.2s'
                                }}
                                onFocus={e => e.target.style.borderColor = 'rgba(167, 139, 250, 0.8)'}
                                onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.15)'}
                            />
                        </div>

                        <div style={{ marginBottom: '24px' }}>
                            <label style={{ display: 'block', color: 'rgba(255,255,255,0.6)', fontSize: '13px', marginBottom: '8px', fontWeight: '500' }}>
                                Senha
                            </label>
                            <div style={{ position: 'relative' }}>
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    required
                                    value={password}
                                    onChange={e => setPassword(e.target.value)}
                                    placeholder="••••••••"
                                    style={{
                                        width: '100%', boxSizing: 'border-box',
                                        background: 'rgba(255,255,255,0.08)',
                                        border: '1px solid rgba(255,255,255,0.15)',
                                        borderRadius: '12px', padding: '12px 48px 12px 16px',
                                        color: 'white', fontSize: '14px',
                                        outline: 'none', transition: 'border-color 0.2s'
                                    }}
                                    onFocus={e => e.target.style.borderColor = 'rgba(167, 139, 250, 0.8)'}
                                    onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.15)'}
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    style={{
                                        position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)',
                                        background: 'none', border: 'none', cursor: 'pointer',
                                        color: 'rgba(255,255,255,0.4)', padding: '4px'
                                    }}
                                >
                                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                                </button>
                            </div>
                        </div>

                        <button
                            type="submit"
                            disabled={loading}
                            style={{
                                width: '100%', padding: '14px',
                                borderRadius: '12px', border: 'none',
                                cursor: loading ? 'not-allowed' : 'pointer',
                                opacity: loading ? 0.7 : 1,
                                fontSize: '14px', fontWeight: '700', color: 'white',
                                background: mode === 'superadmin'
                                    ? 'linear-gradient(135deg, #7c3aed, #4f46e5)'
                                    : 'linear-gradient(135deg, #2563eb, #4f46e5)',
                                boxShadow: '0 8px 24px rgba(79, 70, 229, 0.4)',
                                transition: 'all 0.2s ease',
                                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px'
                            }}
                        >
                            {loading ? (
                                <>
                                    <span style={{
                                        width: '14px', height: '14px', borderRadius: '50%',
                                        border: '2px solid rgba(255,255,255,0.3)',
                                        borderTopColor: 'white',
                                        animation: 'spin 0.8s linear infinite',
                                        display: 'inline-block'
                                    }} />
                                    Entrando...
                                </>
                            ) : (
                                mode === 'superadmin' ? '🔑 Acessar como Superadmin' : 'Entrar'
                            )}
                        </button>
                    </form>
                </div>

                <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.2)', fontSize: '12px', marginTop: '24px' }}>
                    Hotspot Pro© 2026 — Plataforma SaaS de Captive Portal
                </p>
            </div>

            <style>{`
                @keyframes spin { to { transform: rotate(360deg); } }
                input::placeholder { color: rgba(255,255,255,0.25); }
            `}</style>
        </div>
    );
}
