import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface SaasUser {
    token: string;
    name: string;
    email: string;
    role: 'superadmin' | 'tenant';
    company_name?: string;
    plan?: string;
}

interface SaasAuthContextType {
    user: SaasUser | null;
    login: (email: string, password: string, role: 'superadmin' | 'tenant') => Promise<void>;
    logout: () => void;
    isAuthenticated: boolean;
    isSuperadmin: boolean;
}

const SaasAuthContext = createContext<SaasAuthContextType | null>(null);

export function SaasAuthProvider({ children }: { children: ReactNode }) {
    const [user, setUser] = useState<SaasUser | null>(() => {
        const stored = localStorage.getItem('saas_user');
        return stored ? JSON.parse(stored) : null;
    });

    const login = async (email: string, password: string, role: 'superadmin' | 'tenant') => {
        const endpoint = role === 'superadmin' ? '/api/superadmin/login' : '/api/tenant/login';
        const res = await fetch(endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Login falhou');
        const userData: SaasUser = { ...data };
        setUser(userData);
        localStorage.setItem('saas_user', JSON.stringify(userData));
    };

    const logout = () => {
        setUser(null);
        localStorage.removeItem('saas_user');
    };

    return (
        <SaasAuthContext.Provider value={{
            user,
            login,
            logout,
            isAuthenticated: !!user,
            isSuperadmin: user?.role === 'superadmin'
        }}>
            {children}
        </SaasAuthContext.Provider>
    );
}

export function useSaasAuth() {
    const ctx = useContext(SaasAuthContext);
    if (!ctx) throw new Error('useSaasAuth must be used inside SaasAuthProvider');
    return ctx;
}
