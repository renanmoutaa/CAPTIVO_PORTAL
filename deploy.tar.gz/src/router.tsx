import { createBrowserRouter, Navigate } from "react-router-dom";
import { useSaasAuth } from "./contexts/SaasAuthContext";
import { SaasLogin } from "./pages/SaasLogin";
import { GuestPortal } from "./pages/GuestPortal";
import { SuperadminDashboard } from "./components/SuperadminDashboard";
import App from "./App";

// Proteção de rota que exige login e role específico
const ProtectedRoute = ({ children, requiredRole }: { children: React.ReactNode; requiredRole?: string }) => {
    const { isAuthenticated, user } = useSaasAuth();
    if (!isAuthenticated) return <Navigate to="/login" replace />;
    if (requiredRole && user?.role !== requiredRole) return <Navigate to="/login" replace />;
    return <>{children}</>;
};

// Redireciona usuário logado para o painel correto
const AuthRedirect = () => {
    const { isAuthenticated, user } = useSaasAuth();
    if (!isAuthenticated) return <Navigate to="/login" replace />;
    if (user?.role === 'superadmin') return <Navigate to="/superadmin" replace />;
    return <Navigate to="/admin" replace />;
};

export const router = createBrowserRouter([
    {
        path: "/",
        element: <AuthRedirect />,
    },
    {
        path: "/login",
        element: <SaasLogin />,
    },
    {
        // Painel do Superadmin (Master)
        path: "/superadmin",
        element: (
            <ProtectedRoute requiredRole="superadmin">
                <SuperadminDashboard />
            </ProtectedRoute>
        ),
    },
    {
        // Painel do Tenant (Usuário SaaS)
        path: "/admin",
        element: (
            <ProtectedRoute requiredRole="tenant">
                <App />
            </ProtectedRoute>
        ),
    },
    {
        // Portal do Visitante (Captive Portal)
        path: "/guest/s/:site",
        element: <GuestPortal />,
    },
]);
