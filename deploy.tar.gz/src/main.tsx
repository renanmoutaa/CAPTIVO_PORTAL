import { createRoot } from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { router } from "./router";
import { SaasAuthProvider } from "./contexts/SaasAuthContext";
import "./index.css";

createRoot(document.getElementById("root")!).render(
    <SaasAuthProvider>
        <RouterProvider router={router} />
    </SaasAuthProvider>
);