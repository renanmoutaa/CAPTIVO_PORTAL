import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import pkg from 'pg';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const { Pool } = pkg;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

dotenv.config({ path: path.join(__dirname, '.env.local') });
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'hotspot-pro-secret-2026';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'build')));

// Logging middleware
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
});

// ─────────────────────────────────────────────
// Master DB Connection (manages tenants)
// ─────────────────────────────────────────────
const masterPool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    database: process.env.DB_MASTER_NAME || 'hotspot_master',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
});

// Cache of tenant DB connections
const tenantPools = {};

function getTenantPool(dbName) {
    if (!tenantPools[dbName]) {
        tenantPools[dbName] = new Pool({
            host: process.env.DB_HOST || 'localhost',
            port: parseInt(process.env.DB_PORT || '5432'),
            database: dbName,
            user: process.env.DB_USER || 'postgres',
            password: process.env.DB_PASSWORD || 'postgres',
        });
    }
    return tenantPools[dbName];
}

// ─────────────────────────────────────────────
// Auth Middleware
// ─────────────────────────────────────────────
function authMiddleware(role = 'tenant') {
    return (req, res, next) => {
        const token = req.headers.authorization?.replace('Bearer ', '');
        if (!token) return res.status(401).json({ error: 'Token ausente' });
        try {
            const decoded = jwt.verify(token, JWT_SECRET);
            if (role === 'superadmin' && decoded.role !== 'superadmin') {
                return res.status(403).json({ error: 'Acesso negado: requer Superadmin' });
            }
            req.user = decoded;
            next();
        } catch (e) {
            return res.status(401).json({ error: 'Token inválido ou expirado' });
        }
    };
}

// ─────────────────────────────────────────────
// SUPERADMIN ROUTES
// ─────────────────────────────────────────────

// POST /api/superadmin/login
app.post('/api/superadmin/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const result = await masterPool.query(
            'SELECT * FROM superadmins WHERE email = $1', [email]
        );
        const admin = result.rows[0];
        if (!admin || !await bcrypt.compare(password, admin.password_hash)) {
            return res.status(401).json({ error: 'Credenciais inválidas' });
        }
        const token = jwt.sign({ id: admin.id, email: admin.email, role: 'superadmin' }, JWT_SECRET, { expiresIn: '24h' });
        res.json({ token, name: admin.name, email: admin.email, role: 'superadmin' });
    } catch (e) {
        console.error('[SUPERADMIN LOGIN]', e.message);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
});

// POST /api/superadmin/setup (criar primeiro superadmin)
app.post('/api/superadmin/setup', async (req, res) => {
    try {
        const { name, email, password, setupKey } = req.body;
        if (setupKey !== process.env.SETUP_KEY) {
            return res.status(403).json({ error: 'Chave de setup incorreta' });
        }
        const existing = await masterPool.query('SELECT id FROM superadmins LIMIT 1');
        if (existing.rows.length > 0) {
            return res.status(400).json({ error: 'Superadmin já configurado' });
        }
        const hash = await bcrypt.hash(password, 12);
        const result = await masterPool.query(
            'INSERT INTO superadmins (name, email, password_hash) VALUES ($1, $2, $3) RETURNING id, name, email',
            [name, email, hash]
        );
        res.status(201).json({ success: true, admin: result.rows[0] });
    } catch (e) {
        console.error('[SUPERADMIN SETUP]', e.message);
        res.status(500).json({ error: e.message });
    }
});

// GET /api/superadmin/tenants (listar todos usuários)
app.get('/api/superadmin/tenants', authMiddleware('superadmin'), async (req, res) => {
    try {
        const result = await masterPool.query(`
            SELECT t.id, t.name, t.email, t.company_name, t.status, t.controllers_count,
                   t.clients_count, t.created_at, t.last_login, p.name as plan_name
            FROM tenants t
            LEFT JOIN plans p ON t.plan_id = p.id
            ORDER BY t.created_at DESC
        `);
        res.json(result.rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// POST /api/superadmin/tenants (criar novo usuário/tenant)
app.post('/api/superadmin/tenants', authMiddleware('superadmin'), async (req, res) => {
    try {
        const { name, email, password, company_name, plan_id } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({ error: 'name, email e password são obrigatórios' });
        }

        // Gerar nome único para o banco de dados do tenant
        const safeName = email.replace(/[^a-z0-9]/gi, '_').toLowerCase();
        const dbName = `tenant_${safeName}_${Date.now().toString(36)}`;
        const hash = await bcrypt.hash(password, 12);

        // Criar o tenant no master DB
        const result = await masterPool.query(
            `INSERT INTO tenants (name, email, password_hash, company_name, plan_id, db_name)
             VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
            [name, email, hash, company_name || name, plan_id || null, dbName]
        );
        const tenant = result.rows[0];

        // Criar o banco de dados isolado do tenant
        const adminPool = new Pool({
            host: process.env.DB_HOST || 'localhost',
            port: parseInt(process.env.DB_PORT || '5432'),
            database: 'postgres', // Conectar ao postgres padrão para criar DB
            user: process.env.DB_USER || 'postgres',
            password: process.env.DB_PASSWORD || 'postgres',
        });

        await adminPool.query(`CREATE DATABASE "${dbName}"`);
        await adminPool.end();

        // Popular o novo banco com o schema padrão do tenant
        const tenantPool = getTenantPool(dbName);
        const schemaPath = path.join(__dirname, 'database', 'tenant_schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        await tenantPool.query(schema);

        res.status(201).json({
            success: true,
            tenant: { id: tenant.id, name: tenant.name, email: tenant.email, db_name: dbName }
        });
    } catch (e) {
        console.error('[CREATE TENANT]', e.message);
        res.status(500).json({ error: e.message });
    }
});

// PATCH /api/superadmin/tenants/:id (editar tenant)
app.patch('/api/superadmin/tenants/:id', authMiddleware('superadmin'), async (req, res) => {
    try {
        const { name, company_name, plan_id, status } = req.body;
        const { id } = req.params;
        const result = await masterPool.query(
            `UPDATE tenants SET name=$1, company_name=$2, plan_id=$3, status=$4, updated_at=NOW()
             WHERE id=$5 RETURNING *`,
            [name, company_name, plan_id, status, id]
        );
        res.json(result.rows[0]);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// DELETE /api/superadmin/tenants/:id
app.delete('/api/superadmin/tenants/:id', authMiddleware('superadmin'), async (req, res) => {
    try {
        const { id } = req.params;
        const tenant = await masterPool.query('SELECT db_name FROM tenants WHERE id=$1', [id]);
        if (!tenant.rows[0]) return res.status(404).json({ error: 'Tenant não encontrado' });

        await masterPool.query('DELETE FROM tenants WHERE id=$1', [id]);
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// GET /api/superadmin/stats
app.get('/api/superadmin/stats', authMiddleware('superadmin'), async (req, res) => {
    try {
        const [tenants, plans] = await Promise.all([
            masterPool.query(`SELECT status, COUNT(*) as count FROM tenants GROUP BY status`),
            masterPool.query(`SELECT p.name, COUNT(t.id) as users FROM plans p LEFT JOIN tenants t ON t.plan_id = p.id GROUP BY p.name`)
        ]);
        const totalResult = await masterPool.query('SELECT COUNT(*) FROM tenants');
        const controllersResult = await masterPool.query('SELECT SUM(controllers_count) FROM tenants');
        res.json({
            total_tenants: parseInt(totalResult.rows[0].count),
            total_controllers: parseInt(controllersResult.rows[0].sum || '0'),
            by_status: tenants.rows,
            by_plan: plans.rows
        });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ─────────────────────────────────────────────
// TENANT ROUTES
// ─────────────────────────────────────────────

// POST /api/tenant/login
app.post('/api/tenant/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const result = await masterPool.query(
            `SELECT t.*, p.name as plan_name, p.max_controllers, p.max_clients
             FROM tenants t LEFT JOIN plans p ON t.plan_id = p.id WHERE t.email = $1`,
            [email]
        );
        const tenant = result.rows[0];
        if (!tenant || !await bcrypt.compare(password, tenant.password_hash)) {
            return res.status(401).json({ error: 'Credenciais inválidas' });
        }
        if (tenant.status !== 'active') {
            return res.status(403).json({ error: 'Conta suspensa. Contate o suporte.' });
        }
        await masterPool.query('UPDATE tenants SET last_login=NOW() WHERE id=$1', [tenant.id]);
        const token = jwt.sign(
            { id: tenant.id, email: tenant.email, db_name: tenant.db_name, role: 'tenant' },
            JWT_SECRET, { expiresIn: '8h' }
        );
        res.json({
            token,
            name: tenant.name,
            email: tenant.email,
            company_name: tenant.company_name,
            plan: tenant.plan_name,
            max_controllers: tenant.max_controllers,
            role: 'tenant'
        });
    } catch (e) {
        console.error('[TENANT LOGIN]', e.message);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
});

// GET /api/tenant/me
app.get('/api/tenant/me', authMiddleware('tenant'), async (req, res) => {
    try {
        const result = await masterPool.query(
            `SELECT t.id, t.name, t.email, t.company_name, t.status, t.controllers_count,
                    t.clients_count, t.last_login, p.name as plan_name
             FROM tenants t LEFT JOIN plans p ON t.plan_id = p.id WHERE t.id=$1`,
            [req.user.id]
        );
        res.json(result.rows[0]);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// GET /api/tenant/clients
app.get('/api/tenant/clients', authMiddleware('tenant'), async (req, res) => {
    try {
        const pool = getTenantPool(req.user.db_name);
        const result = await pool.query('SELECT * FROM connected_clients ORDER BY connected_at DESC');
        res.json(result.rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// POST /api/tenant/clients (captura de lead do portal)
app.post('/api/tenant/clients', async (req, res) => {
    try {
        const { mac, name, email, phone, cpf, device, location, db_name } = req.body;
        if (!db_name || !mac) return res.status(400).json({ error: 'db_name e mac são obrigatórios' });
        const pool = getTenantPool(db_name);
        await pool.query(
            `INSERT INTO connected_clients (mac, name, email, phone, cpf, device, location, status, connected_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,'online',NOW())
             ON CONFLICT (mac) DO UPDATE SET
                name=EXCLUDED.name, email=EXCLUDED.email, phone=EXCLUDED.phone,
                cpf=EXCLUDED.cpf, device=EXCLUDED.device, location=EXCLUDED.location,
                last_seen=NOW(), status='online'`,
            [mac, name || 'Visitante', email || 'n/a', phone || null, cpf || null, device || 'Desconhecido', location || 'default']
        );
        // Atualizar contagem no master
        await masterPool.query(
            `UPDATE tenants SET clients_count = (SELECT COUNT(*) FROM connected_clients) WHERE db_name=$1`,
            [db_name]
        );
        res.json({ success: true });
    } catch (e) {
        console.error('[CAPTURE CLIENT]', e.message);
        res.status(500).json({ error: e.message });
    }
});

// GET /api/tenant/controllers
app.get('/api/tenant/controllers', authMiddleware('tenant'), async (req, res) => {
    try {
        const pool = getTenantPool(req.user.db_name);
        const result = await pool.query('SELECT * FROM controllers ORDER BY created_at DESC');
        res.json(result.rows);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// POST /api/tenant/controllers
app.post('/api/tenant/controllers', authMiddleware('tenant'), async (req, res) => {
    try {
        const pool = getTenantPool(req.user.db_name);
        const { name, location, ip, model, site, ssid, port, unifi_username, unifi_password, unifi_api_key } = req.body;
        const result = await pool.query(
            `INSERT INTO controllers (name, location, ip, model, site, ssid, port, unifi_username, unifi_password, unifi_api_key)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
            [name, location, ip, model, site || 'default', ssid, port || '8443', unifi_username, unifi_password, unifi_api_key]
        );
        await masterPool.query(
            `UPDATE tenants SET controllers_count = (SELECT COUNT(*) FROM controllers) WHERE db_name=$1`,
            [req.user.db_name]
        );
        res.status(201).json(result.rows[0]);
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// GET /api/tenant/portal-settings
app.get('/api/tenant/portal-settings', authMiddleware('tenant'), async (req, res) => {
    try {
        const pool = getTenantPool(req.user.db_name);
        const result = await pool.query(`SELECT * FROM portal_settings WHERE id='default'`);
        res.json(result.rows[0] || {});
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// PUT /api/tenant/portal-settings
app.put('/api/tenant/portal-settings', authMiddleware('tenant'), async (req, res) => {
    try {
        const pool = getTenantPool(req.user.db_name);
        const fields = req.body;
        const keys = Object.keys(fields).filter(k => k !== 'id');
        const setClause = keys.map((k, i) => `${k}=$${i + 1}`).join(', ');
        const values = keys.map(k => fields[k]);
        await pool.query(
            `UPDATE portal_settings SET ${setClause}, updated_at=NOW() WHERE id='default'`,
            values
        );
        res.json({ success: true });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// ─────────────────────────────────────────────
// Health check
// ─────────────────────────────────────────────
app.get('/api/health', async (req, res) => {
    try {
        await masterPool.query('SELECT 1');
        res.json({ status: 'ok', db: 'connected', time: new Date().toISOString() });
    } catch (e) {
        res.status(500).json({ status: 'error', db: 'disconnected', error: e.message });
    }
});

// Servir React SPA para qualquer rota não-api
app.get('/{*path}', (req, res) => {
    const indexPath = path.join(__dirname, 'build', 'index.html');
    if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
    } else {
        res.json({ status: 'api-only', message: 'Frontend not built — run npm run dev separately' });
    }
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`[HOTSPOT PRO] SaaS API Server running on port ${PORT}`);
    console.log(`[HOTSPOT PRO] Master DB: ${process.env.DB_MASTER_NAME || 'hotspot_master'} on port ${process.env.DB_PORT || '5432'}`);
});
